<?php
/**
 * Part: Content
 * 
 * This file displays the content for a single post or page.
 * It's a reusable template part that can be included in different templates.
 * Shows the title, excerpt, featured image, and read more link.
 * 
 * @package Koko_Mobile_Theme
 */
?>

<article id="post-<?php the_ID(); ?>" <?php post_class('music-card'); ?>>
    <!-- Post/Music Card -->
    <div class="music-card-image">
        <?php if (has_post_thumbnail()) : ?>
            <a href="<?php the_permalink(); ?>">
                <?php the_post_thumbnail('medium', array('class' => 'music-card-cover')); ?>
            </a>
        <?php else : ?>
            <a href="<?php the_permalink(); ?>">
                <img src="<?php echo get_template_directory_uri(); ?>/images/kokohypes-cover.png" alt="<?php the_title_attribute(); ?>" class="music-card-cover">
            </a>
        <?php endif; ?>
    </div>
    
    <!-- Post Info -->
    <div class="music-card-info">
        <h4>
            <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
        </h4>
        <p class="entry-meta">
            <?php
            $categories = get_the_category();
            if (!empty($categories)) {
                echo esc_html($categories[0]->name);
            }
            ?>
        </p>
        
        <?php if (has_excerpt()) : ?>
            <div class="entry-excerpt">
                <?php the_excerpt(); ?>
            </div>
        <?php endif; ?>
    </div>
</article>
