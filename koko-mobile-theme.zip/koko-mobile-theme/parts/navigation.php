<?php
/**
 * Part: Navigation
 * 
 * This file contains the navigation menu markup.
 * It displays the primary navigation menu registered in functions.php.
 * You can customize the menu items from WordPress Admin → Appearance → Menus.
 * 
 * @package Koko_Mobile_Theme
 */
?>

<nav class="main-navigation" role="navigation">
    <?php
    wp_nav_menu(array(
        'theme_location' => 'primary',
        'menu_class'     => 'primary-menu',
        'container'      => 'div',
        'container_class' => 'menu-container',
        'fallback_cb'    => function() {
            echo '<ul class="primary-menu">';
            echo '<li><a href="' . esc_url(home_url('/')) . '">Home</a></li>';
            echo '<li><a href="' . esc_url(home_url('/music')) . '">Music</a></li>';
            echo '<li><a href="' . esc_url(home_url('/mixtape')) . '">Mixtape</a></li>';
            echo '<li><a href="' . esc_url(home_url('/booking')) . '">Booking</a></li>';
            echo '</ul>';
        }
    ));
    ?>
</nav>
